import { Button } from "@/components/ui/button"
import { Star } from "lucide-react"

export default function WorkProcess() {
  return (
    <section className="w-full py-12 md:py-24 border-b">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 relative">
            <h2 className="text-sm font-medium uppercase">Our Approach</h2>
            <h3 className="text-3xl md:text-4xl font-bold">
              We build AI systems that take purposeful actions for social good.
            </h3>
            <p className="text-muted-foreground">
              Our agentic AI tools follow a four-step process: Perceive (gather and process data), Reason (use Large
              Language Models to generate solutions), Act (execute tasks through API integrations with built-in
              guardrails), and Learn (continuously improve through feedback loops).
            </p>
            <Button variant="outline" className="uppercase text-xs">
              Learn More
            </Button>
            <div className="absolute bottom-0 left-0">
              <Star className="size-12 stroke-1" />
            </div>
          </div>
          <div className="md:pl-12">{/* Placeholder for additional content or image */}</div>
        </div>
      </div>
    </section>
  )
}
