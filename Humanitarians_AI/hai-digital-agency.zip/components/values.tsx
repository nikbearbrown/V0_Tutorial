import Image from "next/image"

export default function Values() {
  return (
    <section className="w-full py-12 md:py-24 border-b">
      <div className="container">
        <h2 className="text-3xl font-bold text-center mb-12">OUR VALUES</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <Image
              src="/placeholder.svg?height=600&width=500"
              width={500}
              height={600}
              alt="Diverse team members collaborating"
              className="object-cover"
            />
          </div>
          <div className="space-y-12">
            <div className="space-y-4 border-b pb-8">
              <div className="flex items-center gap-2">
                <div className="size-8 rounded-full border flex items-center justify-center">
                  <span className="text-xs">01</span>
                </div>
                <h3 className="text-xl font-bold">ETHICAL AI</h3>
              </div>
              <p className="text-muted-foreground">
                We are committed to developing AI systems that are fair, transparent, and accountable. We prioritize
                ethical considerations in all our projects and initiatives, ensuring that AI technologies respect human
                rights, privacy, and dignity.
              </p>
            </div>
            <div className="space-y-4 border-b pb-8">
              <div className="flex items-center gap-2">
                <div className="size-8 rounded-full border flex items-center justify-center">
                  <span className="text-xs">02</span>
                </div>
                <h3 className="text-xl font-bold">INCLUSIVITY</h3>
              </div>
              <p className="text-muted-foreground">
                We believe in creating AI solutions that benefit everyone, especially underserved communities. We
                actively work to bridge digital divides and ensure that AI technologies are accessible, inclusive, and
                representative of diverse perspectives and needs.
              </p>
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="size-8 rounded-full border flex items-center justify-center">
                  <span className="text-xs">03</span>
                </div>
                <h3 className="text-xl font-bold">EDUCATION</h3>
              </div>
              <p className="text-muted-foreground">
                We are dedicated to empowering the next generation of AI researchers and practitioners through
                mentorship, education, and hands-on experience. We believe that knowledge sharing and capacity building
                are essential for creating a more equitable AI ecosystem.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
