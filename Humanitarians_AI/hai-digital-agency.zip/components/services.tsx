import { BookOpen, Code, Brain, Leaf } from "lucide-react"

export default function Services() {
  return (
    <section className="w-full py-12 md:py-24 border-b">
      <div className="container">
        <h2 className="text-sm font-medium uppercase mb-8">Key Programs & Initiatives</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="border-t pt-8 md:border-r md:pr-8">
            <div className="mb-4">
              <BookOpen className="size-12 stroke-1" />
            </div>
            <h3 className="text-2xl font-bold mb-4">FELLOWS PROGRAM</h3>
            <p className="text-muted-foreground">
              Mentorship and support for emerging AI researchers, practitioners, and community leaders to develop
              responsible AI solutions that address pressing social challenges.
            </p>
          </div>
          <div className="border-t pt-8">
            <div className="mb-4">
              <Brain className="size-12 stroke-1" />
            </div>
            <h3 className="text-2xl font-bold mb-4">AI RESEARCH</h3>
            <p className="text-muted-foreground">
              Conducting and supporting projects aimed at promoting transparency, fairness, and accountability in AI
              systems.
            </p>
          </div>
          <div className="border-t pt-8 md:border-r md:pr-8">
            <div className="mb-4">
              <Code className="size-12 stroke-1" />
            </div>
            <h3 className="text-2xl font-bold mb-4">AI FOR GOOD SOFTWARE</h3>
            <p className="text-muted-foreground">
              Developing and deploying AI-powered tools for real-world social impact with an emphasis on inclusivity and
              accessibility.
            </p>
          </div>
          <div className="border-t pt-8">
            <div className="mb-4">
              <Leaf className="size-12 stroke-1" />
            </div>
            <h3 className="text-2xl font-bold mb-4">ENTREPRENEURSHIP</h3>
            <p className="text-muted-foreground">
              Fostering innovation and supporting AI startups focused on social impact and ethical technology
              development.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
