export default function Logo() {
  return (
    <div className="relative size-8 border-2 border-foreground flex items-center justify-center">
      <div className="absolute size-2 bg-foreground"></div>
    </div>
  )
}
