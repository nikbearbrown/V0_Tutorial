import Link from "next/link"
import Logo from "@/components/logo"

export default function Footer() {
  return (
    <footer className="w-full py-12 md:py-24 border-t">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Logo />
              <span className="font-bold">H.AI</span>
            </div>
            <p className="text-muted-foreground">
              Humanitarians AI Incorporated
              <br />A 501(c)(3) nonprofit organization
            </p>
            <div className="flex items-center gap-2">
              <Link href="https://linkedin.com" className="size-8 flex items-center justify-center rounded-full border">
                <span className="sr-only">LinkedIn</span>
                <span className="text-xs">IN</span>
              </Link>
              <Link
                href="https://pinterest.com"
                className="size-8 flex items-center justify-center rounded-full border"
              >
                <span className="sr-only">Pinterest</span>
                <span className="text-xs">PT</span>
              </Link>
              <Link href="https://twitter.com" className="size-8 flex items-center justify-center rounded-full border">
                <span className="sr-only">Twitter</span>
                <span className="text-xs">TW</span>
              </Link>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold">Programs</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/fellows-program" className="text-muted-foreground hover:text-foreground">
                  FELLOWS PROGRAM
                </Link>
              </li>
              <li>
                <Link href="/ai-research" className="text-muted-foreground hover:text-foreground">
                  AI RESEARCH
                </Link>
              </li>
              <li>
                <Link href="/ai-for-good" className="text-muted-foreground hover:text-foreground">
                  AI FOR GOOD SOFTWARE
                </Link>
              </li>
              <li>
                <Link href="/entrepreneurship" className="text-muted-foreground hover:text-foreground">
                  ENTREPRENEURSHIP
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold">Projects</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/intelligent-ai-books" className="text-muted-foreground hover:text-foreground">
                  INTELLIGENT AI BOOKS
                </Link>
              </li>
              <li>
                <Link href="/project-dewey" className="text-muted-foreground hover:text-foreground">
                  PROJECT DEWEY
                </Link>
              </li>
              <li>
                <Link href="/shannon-project" className="text-muted-foreground hover:text-foreground">
                  THE SHANNON PROJECT
                </Link>
              </li>
              <li>
                <Link href="/project-tapestry" className="text-muted-foreground hover:text-foreground">
                  PROJECT TAPESTRY
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold">Get Involved</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/volunteer" className="text-muted-foreground hover:text-foreground">
                  VOLUNTEER/MENTOR
                </Link>
              </li>
              <li>
                <Link href="/donate" className="text-muted-foreground hover:text-foreground">
                  DONATE
                </Link>
              </li>
              <li>
                <Link href="/subscribe" className="text-muted-foreground hover:text-foreground">
                  SUBSCRIBE
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground">
                  CONTACT US
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  )
}
